////// IMPORTS //////

//// EXTERNAL ////

// React
import React, { Component, Fragment } from "react";

// Reactstrap
import { Container } from "reactstrap";

//// INTERNAL ////

////// COMPONENT //////

class KBoiler extends Component {
  //// LIFECYCLE ////
  constructor(props) {
    super(props);
  }
  //// RENDERING ////
  render() {
    return <div className="k-page">No content</div>;
  }
  //// MISC ////
}

////// EXPORTS //////
export default KBoiler;
