////// IMPORTS //////

//// EXTERNAL ////

// React
import PropTypes from "prop-types";
import React, { Fragment, useState, useEffect } from "react";

// Reactstrap
import { Container } from "reactstrap";

//// INTERNAL ////

////// COMPONENT //////

function KFuncBoiler(props) {
  //props

  //states

  //effects

  //render
  return <div className="k-boiler">No content</div>;
}

KFuncBoiler.propTypes = {};

////// EXPORTS //////
export default KFuncBoiler;
