import styled from "styled-components";
import { component } from "../Libs/styles";

const KComponent = styled.div`
  ${component}
`;

export default KComponent;
